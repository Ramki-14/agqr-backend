<!DOCTYPE html>
<html>
<head>
    <title>Your Account Credentials</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your account has been created successfully. Below are your credentials:</p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Password:</strong> <?php echo e($password); ?></p>
    <p>Thank you!</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\newagqr-app\resources\views/emails/user_credentials.blade.php ENDPATH**/ ?>